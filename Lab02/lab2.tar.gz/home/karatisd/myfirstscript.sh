
#!/bin/bash

greeting="Hello, World!"

echo $greeting
